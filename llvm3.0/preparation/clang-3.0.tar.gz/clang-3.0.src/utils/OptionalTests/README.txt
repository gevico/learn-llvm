This is a dumping ground for additional tests which do not fit cleanly into the
clang regression tests. For example, tests which are not portable, require
additional software or configuration, take an excessive time to run, or are
flaky can be kept here.
