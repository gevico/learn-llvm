// RUN: %clang_cc1  -fsyntax-only -verify %s
// pr5552

@interface Protocol 
@end

